import React, { useState, useEffect } from "react";

// npm i react-sweet-progress
import { Progress } from "react-sweet-progress";
import "react-sweet-progress/lib/style.css";

export default function Test() {

  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const reportTitle = "Weekly Perfomance Tracker"

  const [sourceData, setSourceData] = useState([
    {
      id: 1,
      title: "Report 1"
    },
    {
      id: 2,
      title: "Report 2"
    },
  ]);

  const [destinationData, setDestinationData] = useState([]);

  const fetchSourceData = () => {
    setDestinationData([...sourceData]);
    localStorage.setItem("data", JSON.stringify(sourceData));
  };


  const loadETL = () => {
    let progress = 0;
    const etlInterval = setInterval(() =>{
      progress += 5;
      if(progress > 100){
        clearInterval(etlInterval)
        fetchSourceData();
        setLoading(false);
      }else{
        setProgress(progress);
        setLoading(true);
      }
    },800)
  }

  const clearData = () => {
    setDestinationData([]);
    localStorage.removeItem("data");
  };

  useEffect(() => {
    const storedData = localStorage.getItem("data");
    if (storedData) {
      setDestinationData(JSON.parse(storedData));
    }
  }, []);

  return (
    <div className="about">
      <h2>Test</h2>
      <p>
        {destinationData.length === 0
          ? loading
            ? "Loading..."
            : "Refresh"
          : `${reportTitle}`}
      </p>
      <button onClick={loadETL}>
        {destinationData.length === 0 ? (loading ? "Loading..." : "Refresh") : "Refresh"}
      </button>
      {loading && <Progress type="circle" percent={progress} status={progress===100? 'success' : 'active'}/>}
      {!loading &&  (destinationData.length === 0 ? (<div>No data</div>) : (<div>Data</div>))}
    </div>
  );
}


// import React, { useState, useEffect } from "react";
// import { Progress } from "react-sweet-progress";
// import "react-sweet-progress/lib/style.css";

// interface DataItem {
//   id: number;
//   title: string;
// }

// const Test: React.FC = () => {
//   const [loading, setLoading] = useState<boolean>(false);
//   const [progress, setProgress] = useState<number>(0);
//   const reportTitle: string = "Weekly Perfomance Tracker";

//   const [sourceData, setSourceData] = useState<DataItem[]>([
//     {
//       id: 1,
//       title: "Report 1"
//     },
//     {
//       id: 2,
//       title: "Report 2"
//     }
//   ]);

//   const [destinationData, setDestinationData] = useState<DataItem[]>([]);

//   const fetchSourceData = () => {
//     setDestinationData([...sourceData]);
//     localStorage.setItem("data", JSON.stringify(sourceData));
//   };

//   const loadETL = () => {
//     let progressValue: number = 0;
//     const etlInterval = setInterval(() => {
//       progressValue += 5;
//       if (progressValue > 100) {
//         clearInterval(etlInterval);
//         fetchSourceData();
//         setLoading(false);
//       } else {
//         setProgress(progressValue);
//         setLoading(true);
//       }
//     }, 800);
//   };

//   const clearData = () => {
//     setDestinationData([]);
//     localStorage.removeItem("data");
//   };

//   useEffect(() => {
//     const storedData: string | null = localStorage.getItem("data");
//     if (storedData) {
//       setDestinationData(JSON.parse(storedData));
//     }
//   }, []);

//   return (
//     <div className="about">
//       <h2>Test</h2>
//       <p>
//         {destinationData.length === 0
//           ? loading
//             ? "Loading..."
//             : "Refresh"
//           : `${reportTitle}`}
//       </p>
//       <button onClick={loadETL}>
//         {destinationData.length === 0 ? (loading ? "Loading..." : "Refresh") : "Refresh"}
//       </button>
//       {loading && <Progress type="circle" percent={progress} status={progress === 100 ? 'success' : 'active'} />}
//       {!loading && (destinationData.length === 0 ? (<div>No data</div>) : (<div>Data</div>))}
//     </div>
//   );
// };

// export default Test;
